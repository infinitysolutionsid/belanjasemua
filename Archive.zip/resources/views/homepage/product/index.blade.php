@extends('welcome')
@section('titlepage','Gallery | Musim Panen')
<?php $y = Date('Y'); ?>
@section('deschomepage','')
@section('content')
@endsection
